# Contributing to Truth Unveiled

Welcome — thank you for helping build Truth Unveiled.  
This document describes how to contribute code, documentation, or governance improvements in a way that helps maintainers review and merge changes quickly.

If you’re contributing for the first time, please read the Code of Conduct in this repository and be constructive and respectful in discussions.
